//
//  ViewController.h
//  MDF1_Week1_Final
//
//  Created by Monica Peters on 10/23/12.
//  Copyright (c) 2012 Monica Peters. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UITextView *introText;
}

//button to show list of items
//on the TableViewController xib view
//connect on the IB
-(IBAction)onClick:(id)sender;

@end
