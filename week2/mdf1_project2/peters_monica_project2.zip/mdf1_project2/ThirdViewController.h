//
//  ThirdViewController.h
//  mdf1_project2
//
//  Created by Monica Peters on 10/29/12.
//  Copyright (c) 2012 Monica Peters. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController
{
    IBOutlet UIButton *contactMonica;
}

//button to close this detail view
-(IBAction)onClick:(id)sender;

@end
